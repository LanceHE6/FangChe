<script setup>

</script>

<template>
    <h4>hhhhhh</h4>
  <router-link to="/study/zaixian">在线学习</router-link>
  <router-link to="/study/studyPath">学习路径</router-link>
</template>

<style scoped>

</style>