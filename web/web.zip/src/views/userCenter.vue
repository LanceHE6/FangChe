<script setup>

</script>

<template>
<h1>个人中心</h1>
</template>

<style scoped>

</style>