<script setup>

</script>

<template>
  <div class="common-layout">
    <el-container>
      <el-header style="background: white;height: 20vh;width: 30vw">Header</el-header>
      <el-main>Main</el-main>
    </el-container>
<!--    <router-link to="/study">学习</router-link>-->
  </div>
</template>

<style scoped>

</style>