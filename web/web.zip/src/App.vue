<script setup>


</script>

<template>
  <div class="top">
  <nav>
  <router-link to="/"> 首页</router-link>
    <router-link to="/study">学习</router-link>
    <router-link to="/evalution">测评</router-link>
  <router-link to="/login">前往登录界面</router-link>
<!--    <router-link to="/user">用户名{{}}</router-link>-->
  </nav>
    <div class="user">
      <el-popover placement="bottom" style="width: 3vw;" trigger="hover">
        <template #reference>
          <el-button style="color: #00BD7E;margin-top: 3px;font-size: 3vh;border: none;background-color: transparent">用户名</el-button>
        </template>
        <div class="centerL">
        <router-link style="color: #181818" to="/user">个人中心</router-link>
        <el-button style="border: none;font-size: 1.9vh;padding:0;margin-top: 0.2vh" @click="lagout">退出登录</el-button>
        </div>
      </el-popover>
    </div>
  </div>



<!--  路由的显示入口-->
  <router-view/>
</template>

<style scoped>
.top{
  position: fixed;
  top: 0;
  width: 100vw;
  height: 8vh;
  background: #181818;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 3vh;
}
.user{
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: transparent;
}
.centerL{
  font-size: 1.9vh;
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-direction: column;
}
</style>
