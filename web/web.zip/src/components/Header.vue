<script setup>

</script>

<template>
  <div class="top">

  </div>
</template>

<style scoped>
.top{
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 10vh;
  background: #181818;
}
</style>